package com.chris4rldev.xerologin.commands;

import com.chris4rldev.xerologin.XeroLogin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LoginCommand implements CommandExecutor {

    private final XeroLogin plugin;

    public LoginCommand(XeroLogin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }

        if (args.length != 1) {
            player.sendMessage(plugin.msg("login-usage"));
            return true;
        }

        if (!plugin.getDataManager().isRegistered(player.getUniqueId())) {
            player.sendMessage(plugin.msg("login-not-registered"));
            return true;
        }

        if (plugin.getDataManager().isLoggedIn(player.getUniqueId())) {
            player.sendMessage(plugin.msg("login-already"));
            return true;
        }

        if (!plugin.getDataManager().checkPassword(player.getUniqueId(), args[0])) {
            player.sendMessage(plugin.msg("login-wrong-password"));
            return true;
        }

        plugin.getDataManager().setLoggedIn(player.getUniqueId(), true);
        String ip = player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : "unknown";
        plugin.getDataManager().recordSession(player.getUniqueId(), ip);
        player.sendMessage(plugin.msg("login-success"));
        player.resetTitle();
        return true;
    }
}
