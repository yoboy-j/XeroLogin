package com.chris4rldev.xerologin.listeners;

import com.chris4rldev.xerologin.PlayerDataManager;
import com.chris4rldev.xerologin.XeroLogin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class AuthListener implements Listener {

    private final XeroLogin plugin;

    public AuthListener(XeroLogin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        PlayerDataManager data = plugin.getDataManager();
        String ip = player.getAddress() != null ? player.getAddress().getAddress().getHostAddress() : "unknown";

        if (!data.isRegistered(uuid)) {
            showTitle(player, plugin.msg("register-title"), plugin.msg("register-subtitle"));
            return;
        }

        if (data.hasValidSession(uuid, ip)) {
            data.setLoggedIn(uuid, true);
            return;
        }

        data.setLoggedIn(uuid, false);
        showTitle(player, plugin.msg("login-title"), plugin.msg("login-subtitle"));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        plugin.getDataManager().setLoggedIn(uuid, false);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onMove(PlayerMoveEvent event) {
        if (!plugin.getConfig().getBoolean("settings.restrictions.block-movement", true)) {
            return;
        }
        Player player = event.getPlayer();
        if (isBlocked(player)) {
            // allow looking around, block actual position changes
            if (event.getFrom().getX() != event.getTo().getX()
                    || event.getFrom().getY() != event.getTo().getY()
                    || event.getFrom().getZ() != event.getTo().getZ()) {
                event.setTo(event.getFrom());
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!plugin.getConfig().getBoolean("settings.restrictions.block-commands", true)) {
            return;
        }
        Player player = event.getPlayer();
        if (!isBlocked(player)) {
            return;
        }

        String cmd = event.getMessage().substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        List<String> allowed = plugin.getConfig().getStringList("settings.restrictions.allowed-commands");
        if (!allowed.contains(cmd)) {
            event.setCancelled(true);
            player.sendMessage(plugin.msg("not-logged-in"));
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        if (!plugin.getConfig().getBoolean("settings.restrictions.block-chat", true)) {
            return;
        }
        Player player = event.getPlayer();
        if (isBlocked(player)) {
            event.setCancelled(true);
            player.sendMessage(plugin.msg("not-logged-in"));
        }
    }

    private boolean isBlocked(Player player) {
        return !plugin.getDataManager().isLoggedIn(player.getUniqueId());
    }

    private void showTitle(Player player, String title, String subtitle) {
        player.sendTitle(title, subtitle, 10, 100, 20);
    }
}
