package com.chris4rldev.xerologin;

import com.chris4rldev.xerologin.util.PasswordUtil;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Stores account data (one YAML file per player) and tracks who is
 * currently authenticated in-memory (no persistent sessions unless
 * configured).
 */
public class PlayerDataManager {

    private final XeroLogin plugin;
    private final File dataFolder;

    private final Set<UUID> loggedIn = new HashSet<>();
    private final Map<UUID, Long> lastLoginTime = new HashMap<>();
    private final Map<UUID, String> lastLoginIp = new HashMap<>();

    public PlayerDataManager(XeroLogin plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "playerdata");
        if (!dataFolder.exists()) {
            dataFolder.mkdirs();
        }
    }

    private File fileFor(UUID uuid) {
        return new File(dataFolder, uuid.toString() + ".yml");
    }

    public boolean isRegistered(UUID uuid) {
        return fileFor(uuid).exists();
    }

    public void register(UUID uuid, String password) {
        String salt = PasswordUtil.generateSalt();
        String hash = PasswordUtil.hash(password, salt);

        YamlConfiguration config = new YamlConfiguration();
        config.set("salt", salt);
        config.set("hash", hash);
        try {
            config.save(fileFor(uuid));
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save account data for " + uuid + ": " + e.getMessage());
        }
    }

    public boolean checkPassword(UUID uuid, String password) {
        if (!isRegistered(uuid)) {
            return false;
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(fileFor(uuid));
        String salt = config.getString("salt");
        String hash = config.getString("hash");
        if (salt == null || hash == null) {
            return false;
        }
        return PasswordUtil.matches(password, salt, hash);
    }

    public void changePassword(UUID uuid, String newPassword) {
        register(uuid, newPassword);
    }

    public void unregister(UUID uuid) {
        File f = fileFor(uuid);
        if (f.exists()) {
            f.delete();
        }
        loggedIn.remove(uuid);
    }

    public boolean isLoggedIn(UUID uuid) {
        return loggedIn.contains(uuid);
    }

    public void setLoggedIn(UUID uuid, boolean value) {
        if (value) {
            loggedIn.add(uuid);
        } else {
            loggedIn.remove(uuid);
        }
    }

    public void recordSession(UUID uuid, String ip) {
        lastLoginTime.put(uuid, System.currentTimeMillis());
        lastLoginIp.put(uuid, ip);
    }

    /**
     * Returns true if the player has a still-valid session (feature is
     * enabled in config, they reconnect from the same IP, within the
     * configured timeout).
     */
    public boolean hasValidSession(UUID uuid, String ip) {
        if (!plugin.getConfig().getBoolean("settings.session.enabled", false)) {
            return false;
        }
        Long last = lastLoginTime.get(uuid);
        String lastIp = lastLoginIp.get(uuid);
        if (last == null || lastIp == null || !lastIp.equals(ip)) {
            return false;
        }
        long timeoutMs = plugin.getConfig().getLong("settings.session.timeout-minutes", 10) * 60_000L;
        return (System.currentTimeMillis() - last) <= timeoutMs;
    }
}
