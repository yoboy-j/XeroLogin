package com.chris4rldev.xerologin.commands;

import com.chris4rldev.xerologin.XeroLogin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ChangePasswordCommand implements CommandExecutor {

    private final XeroLogin plugin;

    public ChangePasswordCommand(XeroLogin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }

        if (args.length != 2) {
            player.sendMessage(plugin.msg("changepass-usage"));
            return true;
        }

        if (!plugin.getDataManager().isLoggedIn(player.getUniqueId())) {
            player.sendMessage(plugin.msg("not-logged-in"));
            return true;
        }

        if (!plugin.getDataManager().checkPassword(player.getUniqueId(), args[0])) {
            player.sendMessage(plugin.msg("changepass-wrong-old"));
            return true;
        }

        plugin.getDataManager().changePassword(player.getUniqueId(), args[1]);
        player.sendMessage(plugin.msg("changepass-success"));
        return true;
    }
}
