package com.chris4rldev.xerologin;

import com.chris4rldev.xerologin.commands.ChangePasswordCommand;
import com.chris4rldev.xerologin.commands.LoginCommand;
import com.chris4rldev.xerologin.commands.LogoutCommand;
import com.chris4rldev.xerologin.commands.RegisterCommand;
import com.chris4rldev.xerologin.commands.XeroLoginCommand;
import com.chris4rldev.xerologin.listeners.AuthListener;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public class XeroLogin extends JavaPlugin {

    private PlayerDataManager dataManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.dataManager = new PlayerDataManager(this);

        getServer().getPluginManager().registerEvents(new AuthListener(this), this);

        getCommand("register").setExecutor(new RegisterCommand(this));
        getCommand("login").setExecutor(new LoginCommand(this));
        getCommand("logout").setExecutor(new LogoutCommand(this));
        getCommand("changepassword").setExecutor(new ChangePasswordCommand(this));
        getCommand("xerologin").setExecutor(new XeroLoginCommand(this));

        getLogger().info("XeroLogin has been enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("XeroLogin has been disabled.");
    }

    public PlayerDataManager getDataManager() {
        return dataManager;
    }

    /** Translates '&' color codes in a config message. */
    public String msg(String path) {
        String raw = getConfig().getString("messages." + path, "");
        return ChatColor.translateAlternateColorCodes('&', raw);
    }
}
