package com.chris4rldev.xerologin.commands;

import com.chris4rldev.xerologin.XeroLogin;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class XeroLoginCommand implements CommandExecutor {

    private final XeroLogin plugin;

    public XeroLoginCommand(XeroLogin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("xerologin.admin")) {
            sender.sendMessage(plugin.msg("no-permission"));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    "&9XeroLogin &7- /xerologin <reload|changepass|unregister> [player] [password]"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aXeroLogin config reloaded."));
            }
            case "changepass" -> {
                if (args.length != 3) {
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                            "&cUsage: /xerologin changepass <player> <newPassword>"));
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                plugin.getDataManager().changePassword(target.getUniqueId(), args[2]);
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                        "&aPassword changed for " + args[1] + "."));
            }
            case "unregister" -> {
                if (args.length != 2) {
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                            "&cUsage: /xerologin unregister <player>"));
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                plugin.getDataManager().unregister(target.getUniqueId());
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                        "&aUnregistered " + args[1] + ". They can /register again."));
            }
            default -> sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    "&9XeroLogin &7- /xerologin <reload|changepass|unregister> [player] [password]"));
        }
        return true;
    }
}
