package com.chris4rldev.xerologin.commands;

import com.chris4rldev.xerologin.XeroLogin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RegisterCommand implements CommandExecutor {

    private final XeroLogin plugin;

    public RegisterCommand(XeroLogin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }

        if (args.length != 2) {
            player.sendMessage(plugin.msg("register-usage"));
            return true;
        }

        if (plugin.getDataManager().isRegistered(player.getUniqueId())) {
            player.sendMessage(plugin.msg("register-already"));
            return true;
        }

        String password = args[0];
        String repeat = args[1];

        if (!password.equals(repeat)) {
            player.sendMessage(plugin.msg("register-mismatch"));
            return true;
        }

        int min = plugin.getConfig().getInt("settings.security.min-password-length", 4);
        int max = plugin.getConfig().getInt("settings.security.max-password-length", 32);

        if (password.length() < min) {
            player.sendMessage(plugin.msg("register-too-short").replace("%min%", String.valueOf(min)));
            return true;
        }
        if (password.length() > max) {
            player.sendMessage(plugin.msg("register-too-long").replace("%max%", String.valueOf(max)));
            return true;
        }

        plugin.getDataManager().register(player.getUniqueId(), password);
        player.sendMessage(plugin.msg("register-success"));
        return true;
    }
}
