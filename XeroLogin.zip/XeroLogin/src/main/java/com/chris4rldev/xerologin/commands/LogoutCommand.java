package com.chris4rldev.xerologin.commands;

import com.chris4rldev.xerologin.XeroLogin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LogoutCommand implements CommandExecutor {

    private final XeroLogin plugin;

    public LogoutCommand(XeroLogin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("player-only"));
            return true;
        }

        plugin.getDataManager().setLoggedIn(player.getUniqueId(), false);
        player.sendMessage(plugin.msg("logout-success"));
        player.sendTitle(plugin.msg("login-title"), plugin.msg("login-subtitle"), 10, 100, 20);
        return true;
    }
}
