# XeroLogin

A simple, clean register/login plugin for Paper 1.21.x servers, by **chris4rldev**.

## What it does

- New players see a **blue "REGISTER"** title with **white** subtext:
  `Type /register <password> <repeat>`
- Registered players see a **blue "LOGIN"** title with **white** subtext:
  `Type /login <password> to login`
- No persistent sessions by default — every join requires `/login` again.
  Sessions are optional and configurable (`config.yml`).
- While unauthenticated, players are frozen: no movement, no chat, no
  commands except `/register` and `/login` (all configurable).

## Commands

| Command | Description |
|---|---|
| `/register <password> <repeat>` | Create your account |
| `/login <password>` | Log in |
| `/logout` | Log out manually |
| `/changepassword <old> <new>` | Change your password |
| `/xerologin reload` | Reload config.yml |
| `/xerologin changepass <player> <newPassword>` | Admin: force-change a password |
| `/xerologin unregister <player>` | Admin: wipe an account so it can register again |

Admin commands require the `xerologin.admin` permission (OP by default).

## Configuration

See `config.yml` — you can edit every message/title, toggle sessions,
set min/max password length, and control what's blocked pre-login.

---

## Building it yourself (Termux, same as ValtherStacker)

1. Install the JDK 21 and Gradle if you haven't already:
   ```
   pkg install openjdk-21 gradle
   ```
2. Move into the project folder:
   ```
   cd XeroLogin
   ```
3. Build the jar:
   ```
   ./gradlew shadowJar
   ```
   (First run downloads Gradle + dependencies, so you'll need internet.)
4. Your plugin jar will be at:
   ```
   build/libs/XeroLogin-1.0.0.jar
   ```
5. Drop that jar into your server's `plugins/` folder and restart.

> If `./gradlew` isn't executable, run `chmod +x gradlew` first.

## Putting it on GitHub

1. Create a new repo on GitHub, e.g. `XeroLogin`.
2. In the project folder:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/XeroLogin.git
   git push -u origin main
   ```
3. Add a `.gitignore` (included) so you don't commit the `build/` folder.

## Publishing on Modrinth

1. Create a Modrinth account and start a new project (type: Plugin).
2. Fill in the name (XeroLogin), summary, and description — you can
   reuse this README as the description.
3. Set the category to "Utility" or "Management", and tag it for
   Paper 1.21.x.
4. Upload the built jar (`build/libs/XeroLogin-1.0.0.jar`) as your
   first version file.
5. Link your GitHub repo in the project's "Links" section (optional
   but recommended).
6. Submit for review.

## License

MIT — do whatever you want with it, just keep the credit.
